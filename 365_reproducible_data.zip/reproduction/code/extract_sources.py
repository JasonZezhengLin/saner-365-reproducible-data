import json,re,datetime,hashlib,zipfile,io,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1];raw=R/'data/raw/public_pages';records=[]
def main_record(n,s):
 main=[];comments={};types=collections.Counter()
 def walk(x):
  if isinstance(x,dict):
   if x.get('number')==n and 'body' in x and 'timelineItems' in x:main.append(x)
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 for m in re.finditer(r'<script[^>]*type="application/json"[^>]*>(.*?)</script>',s,re.S):
  try:walk(json.loads(m.group(1)))
  except json.JSONDecodeError:pass
 if not main:return {'issue':n,'status':'MainIssueNodeNotLocated'}
 x=max(main,key=lambda a:len(json.dumps(a)));events=[];pages={}
 for key in ['timelineItems','backTimelineItems']:
  q=x.get(key) or {};pages[key]=q.get('pageInfo');nodes=q.get('nodes',[])+[e.get('node',{}) for e in q.get('edges',[])]
  for a in nodes:
   types[a.get('__typename','unknown')]+=1
   if a.get('__typename')=='IssueComment' and str(a.get('url','')).startswith(f'https://github.com/apache/echarts/issues/{n}#'):
    fields=['databaseId','url','createdAt','lastEditedAt','authorAssociation','body','isHidden','isMinimized','minimizedReason'];r={k:a.get(k) for k in fields};r['author_login']=(a.get('author') or {}).get('login');r['author_type']=(a.get('author') or {}).get('__typename');comments[a['databaseId']]=r
   else:events.append(a)
 fields=['number','databaseId','url','createdAt','updatedAt','title','body','bodyVersion','totalCommentsCount','state','stateReason','duplicateOf'];out={k:x.get(k) for k in fields};out.update(issue=n,status='Located',author_login=(x.get('author') or {}).get('login'),labels=[a.get('node',a).get('name') for a in (x.get('labels') or {}).get('edges',[])],comments=sorted(comments.values(),key=lambda a:(a['createdAt'],a['databaseId'])),page_info=pages,timeline_types=dict(types),source_sha256=hashlib.sha256(s.encode()).hexdigest());out['comments_complete_by_total_count']=len(comments)==x.get('totalCommentsCount');out['translation_comments']=[a for a in out['comments'] if a['author_login']=='echarts-bot' and 'TRANSLATED' in (a['body'] or '')];out['non_comment_events']=events;return out
for p in sorted(raw.glob('*.html'),key=lambda a:int(a.stem)):
 a=main_record(int(p.stem),p.read_text());records.append(a);print(json.dumps({'issue':a['issue'],'status':a['status'],'comments':len(a.get('comments',[])),'expected':a.get('totalCommentsCount'),'complete':a.get('comments_complete_by_total_count'),'translation':len(a.get('translation_comments',[]))}),flush=True)
p=R/'data/raw/additional_targets.zip'
if p.exists():
 with zipfile.ZipFile(p) as z:
  for name in z.namelist():
   if name.endswith('.html'):records.append(main_record(int(name[:-5]),z.read(name).decode()))
frame=json.loads((R/'data/raw/duplicate_frame_2024.json').read_text());items=frame['items'];by={a['issue']:a for a in records};validation=[]
for item in items:
 a=by[item['number']];v={'issue':item['number'],'api_expected_comments':item['comments'],'html_count':len(a.get('comments',[])),'api_body_equal':a.get('body')==item['body'],'api_created_equal':a.get('createdAt')==item['created_at']};hp=R/'data/raw'/f"comments_{item['number']}.http"
 if hp.exists():
  b=hp.read_bytes()
  try:
   j=json.loads(b.rsplit(b'\r\n\r\n',1)[-1]);v['api_comment_response_is_array']=isinstance(j,list)
   if isinstance(j,list):
    ac={x['id']:(x['body'],x['created_at']) for x in j};hc={x['databaseId']:(x['body'],x['createdAt']) for x in a['comments']};v['rest_html_comments_exact_equal']=ac==hc
  except Exception as e:v['rest_parse_error']=repr(e)
 validation.append(v)
out={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'frame':'current duplicate-labeled issue reports created in 2024,apache/echarts;not all-report duplication prevalence','n_frame':len(items),'reports':[by[x['number']] for x in items],'linked_source_snapshots':[x for x in records if x['issue'] not in {a['number'] for a in items}],'validation':validation,'scope':'current public snapshots;body edit history not recovered,translation created/lastEdited preserved;duplicate assertion distinct from same root cause'}
(R/'results').mkdir(exist_ok=True);p=R/'results/public_snapshot_extraction.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2));print('EXTRACTION_ARCHIVED',p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest(),flush=True)

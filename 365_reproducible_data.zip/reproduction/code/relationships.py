import json,datetime,hashlib,collections
from pathlib import Path
R=Path(__file__).resolve().parents[1]
d=json.loads((R/'results/public_snapshot_extraction.json').read_text())
by={x['issue']:x for x in d['reports']+d['linked_source_snapshots']}
manual=[
(19575,'EN','feature',[19367],[],'Unknown'),
(19585,'EN','bug',[19560],[],'Unknown'),
(19660,'ZH','bug',[17763],[],'Unknown'),
(19810,'EN','bug',[19811],[19736],'CurrentBodyPriorReportReference'),
(19920,'ZH','bug',[],[18327],'Unknown'),
(19948,'EN','feature',[19927],[],'ExplicitAuthorSelfResubmissionInComment'),
(19955,'ZH','bug',[19946],[],'Unknown'),
(19962,'EN','bug',[19946],[],'Unknown'),
(19963,'EN','bug',[19946],[],'Unknown'),
(20057,'EN','bug',[19125],[],'Unknown'),
(20095,'EN','bug',[15103],[],'Unknown'),
(20127,'ZH','bug',[15467,19726],[],'Unknown'),
(20142,'EN','feature',[5181],[],'Unknown'),
(20146,'EN','bug',[20119],[17209],'CurrentBodyPriorReportReference'),
(20189,'ZH','bug',[15467],[],'Unknown'),
(20382,'EN','bug',[],[14051],'CurrentBodyExplicitStaleReportReference'),
(20479,'ZH','feature',[],[20473],'CurrentBodyOwnEarlierBugReference')]
langs={19367:'EN',19560:'Mixed_ZH_prose_EN_error_title',17763:'ZH',19811:'EN',19927:'EN',19946:'ZH',19125:'EN',15103:'EN',15467:'ZH',19726:'EN',5181:'EN',20119:'ZH',14051:'EN',20473:'ZH',17209:'not_coded',19736:'not_coded',18327:'not_coded_related_PR'}
rows=[];edges=[]
def dt(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
for n,lang,kind,targets,refs,awareness in manual:
 x=by[n];assert x['comments_complete_by_total_count']
 row={'issue':n,'narrative_language_source_coding':lang,'current_request_template_source_coding':kind,'explicit_duplicate_targets':targets,'other_visible_references':refs,'author_awareness_evidence_class':awareness,'filing_time_search_or_reading_behavior':'Unknown','body_edit_history':'NotRecovered','evidence_source_sha256':x['source_sha256'],'comments_total':x['totalCommentsCount']}
 if n==19920:row['relation_note']='See18327 is a related source reference,not an explicit duplicate-of assertion;public document is a pull request'
 if n==20382:row['relation_note']='Duplicate label plus author old-report reference;no human duplicate-target comment'
 if n==20479:row['relation_note']='Duplicate complaint has no numbered target;body points to own previous bug;inferred target excluded from explicit-link main graph'
 for target in targets:
  y=by[target];matches=[c for c in x['comments'] if str(target) in c['body'] and 'duplicate of' in c['body'].lower()]
  assert matches,(n,target);c=matches[0];translations=[z for z in y.get('translation_comments',[]) if dt(z['createdAt'])<dt(x['createdAt']) and z['lastEditedAt'] is None]
  edge={'report':n,'target':target,'report_language':lang,'target_language':langs[target],'target_created_minus_report_seconds':(dt(y['createdAt'])-dt(x['createdAt'])).total_seconds(),'target_is_earlier':dt(y['createdAt'])<dt(x['createdAt']),'assertion_url':c['url'],'assertion_created':c['createdAt'],'assertion_last_edited':c['lastEditedAt'],'assertion_author_association':c['authorAssociation'],'same_report_target_author':x['author_login']==y['author_login'],'prior_translation_current_text_unedited':bool(translations),'translation_created_times':[z['createdAt'] for z in translations],'translation_read_or_indexed':'Unknown','root_cause_equivalence':'NotValidated'}
  if translations:edge['translation_lead_hours']=(dt(x['createdAt'])-dt(translations[0]['createdAt'])).total_seconds()/3600
  edges.append(edge)
 rows.append(row)
strict_cross=[e for e in edges if (e['report_language'],e['target_language']) in [('EN','ZH'),('ZH','EN')]]
translated_en=[e for e in edges if e['report_language']=='EN' and e['target_language']=='ZH' and e['target_is_earlier'] and e['prior_translation_current_text_unedited']]
summary={'n_frame':17,'n_comments_complete':sum(x['comments_complete_by_total_count'] for x in d['reports']),'n_comments':sum(x['totalCommentsCount'] for x in d['reports']),'current_request_templates':dict(collections.Counter(x['current_request_template_source_coding'] for x in rows)),'report_languages':dict(collections.Counter(x['narrative_language_source_coding'] for x in rows)),'explicit_duplicate_linked_reports':sum(bool(x['explicit_duplicate_targets']) for x in rows),'explicit_edges':len(edges),'later_named_targets':[e for e in edges if not e['target_is_earlier']],'strict_cross_language_edges':strict_cross,'translated_ZH_target_to_later_EN_report_edges':translated_en,'translated_ZH_target_source_count':len({e['target'] for e in translated_en}),'explicit_self_resubmission_reports':[x['issue'] for x in rows if x['author_awareness_evidence_class']=='ExplicitAuthorSelfResubmissionInComment'],'target_language_sensitivity':'19560 has Chinese narrative around an English copied error/title;retained Mixed in main coding;ZH sensitivity adds19585 as a cross-language edge','scope':'finite current-label frame;not all2024issues,not duplication prevalence,not language/translation causal effect;one-hop asserted relation,not verified independent bugs'}
out={'coding_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'annotator':'Frozen source labels','input_sha256':hashlib.sha256((R/'results/public_snapshot_extraction.json').read_bytes()).hexdigest(),'rows':rows,'edges':edges,'summary':summary,'conceptual_controls':'Current body links are not filing-time awareness;created unedited translation is public availability,not reading or discoverability;related references and CSS color literals are not duplicate edges'}
p=R/'results/issue_relationships.json';p.write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)

from pathlib import Path
import json,sys,subprocess,os
D=Path(__file__).resolve().parent
def rename(x):
 if isinstance(x,dict):return {k:v if not isinstance(v,(dict,list)) else rename(v) for k,v in x.items() if not k.endswith('sha256')}
 if isinstance(x,list):return [rename(v) for v in x]
 return x
for script in ['extract_sources.py','relationships.py']:
 p=subprocess.run([sys.executable,'-B',str(D/'code'/script)],cwd=D,capture_output=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
 if p.returncode:sys.stderr.buffer.write(p.stderr);raise SystemExit(p.returncode)
ex=json.loads((D/'results/public_snapshot_extraction.json').read_text());ex=rename({k:ex[k] for k in ['n_frame','reports','linked_source_snapshots','validation']})
rel=json.loads((D/'results/issue_relationships.json').read_text());rel=rename({k:rel[k] for k in ['rows','edges','summary','conceptual_controls']})
assert ex==json.loads((D/'expected/extraction.json').read_text())
assert rel==json.loads((D/'expected/relationships.json').read_text())
rows=rel['rows'];edges=rel['edges']
cross=[e for e in edges if (e['report_language'],e['target_language']) in [('EN','ZH'),('ZH','EN')]]
leads=[e['translation_lead_hours'] for e in cross if e.get('prior_translation_current_text_unedited') and e['report_language']=='EN']
assert len(rows)==17 and len(edges)==15 and len(cross)==4 and len(leads)==3
print(json.dumps({'reports':len(rows),'comments':sum(len(x['comments']) for x in ex['reports']),'explicit_edges':len(edges),'cross_language_edges':len(cross),'translation_lead_hours':leads,'matched':True}))
